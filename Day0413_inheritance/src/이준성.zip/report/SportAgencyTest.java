package report;

public class SportAgencyTest {

	public static void main(String[] args) {

		SportsAgency sport = new SportsAgency();

		sport.start();
		sport.play();

	}
}
